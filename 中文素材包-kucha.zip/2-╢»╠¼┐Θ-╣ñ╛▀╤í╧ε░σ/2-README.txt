声明：所有素材均为”麦名亮/kucha“制作，仅用于折纸交流。当你分享该文件时，请务必附带“README”以便于我后面收集意见及修改。

一、CAD动态块及工具选项板使用教程
安装AutoCAD2007及以上版本，打开文件”折纸符号-动态库“。参考内部的注释文件安装素材。

二、素材来因：
前段时间我和chen xiao聊了AD-Affinity Designer，同时我也和212moving聊了Ai-Adobe illustrator，
他们都预设了自己的符号库，这使得他们的绘图速度得到了极大的提升。我记得AutoCAD可以做到同样的事情，于是我开始关注这方面的消息。
直到一个月前，我才意识到到，我可以使用CAD的“动态块+属性块+工具选项板”实现这样的事情。
于是我一直在寻找时间，直到前天（星期五，没有加班），我意识到我将有两天的假期。于是我通过“百度+谷歌+CAD的知识论坛”，收集一切我需要的资料，然后不断尝试。最终，我做到了。

接着，我求助了折纸艺术家，希望得到“原创的作品”去测试目前的成果，很高兴我得到了Syn设计的”冰山-iceberg"。于是我花了大概8小时，一边绘制折图，一边完善折纸符号（视频过程：https://www.bilibili.com/video/BV1At4y127g6)

现在，我得到了一个图解和一些成果。我把他们上传到Dropbox。我希望你可以使用这些符号在CAD中绘制你的图纸并且给我一些建议。同时，Syn说我可以随意的处置图纸，于是我决定分享包括DWG文件在内的所有素材，希望对你绘制图解有一些帮助。更重要的是，这个作品很棒，你可以尽情享受折叠的过程。

Download：https://www.dropbox.com/sh/5c1g92rw9lrffv3/AABKn76Ts1ystfdcoPwyz_EQa?dl=0

如果你有一些任何建议或者疑问，欢迎联系我（e-mail）：kucha0609@qq.com


三、其它帮助资料
关于工具选项卡→https://knowledge.autodesk.com/zh-hans/support/autocad/learn-explore/caas/CloudHelp/cloudhelp/2021/CHS/AutoCAD-Core/files/GUID-6B20D7DF-447A-4A8D-8FF1-8339CF54FFBD-htm.html?st=%E5%B7%A5%E5%85%B7%E9%80%89%E9%A1%B9%E5%8D%A1%20%E6%9B%B4%E6%96%B0

创建和修改工具选项板的步骤→https://knowledge.autodesk.com/zh-hans/support/autocad/learn-explore/caas/CloudHelp/cloudhelp/2021/CHS/AutoCAD-Core/files/GUID-7946B6B8-654A-4708-BEBE-F4142E555DF0-htm.html

关于使用设计中心添加内容→https://knowledge.autodesk.com/zh-hans/support/autocad/learn-explore/caas/CloudHelp/cloudhelp/2021/CHS/AutoCAD-Core/files/GUID-B2BA9E9E-942F-4E01-89C9-DBA1AB9A2C6A-htm.html?st=%E5%B7%A5%E5%85%B7%E9%80%89%E9%A1%B9%E6%9D%BF%20%E6%9B%B4%E6%96%B0

修改工具选项板的外观的步骤→https://knowledge.autodesk.com/zh-hans/support/autocad/learn-explore/caas/CloudHelp/cloudhelp/2021/CHS/AutoCAD-Core/files/GUID-B578A008-7C57-4CD1-8146-FAEF52588DD9-htm.html?st=%E5%B7%A5%E5%85%B7%E9%80%89%E9%A1%B9%E6%9D%BF%20%E6%9B%B4%E6%96%B0

使用块工具的步骤→https://knowledge.autodesk.com/zh-hans/support/autocad/learn-explore/caas/CloudHelp/cloudhelp/2021/CHS/AutoCAD-Core/files/GUID-883A13B9-09F4-4B03-8EF0-738F652AC2D3-htm.html?st=%E5%9C%A8%E5%B7%A5%E5%85%B7%E9%80%89%E9%A1%B9%E6%9D%BF%E4%B8%8A%E6%9B%B4%E6%96%B0%E5%9D%97%E5%AE%9A%E4%B9%89

工具选项卡导入与导出→https://knowledge.autodesk.com/zh-hans/support/autocad/learn-explore/caas/sfdcarticles/sfdcarticles/CHS/How-to-export-and-import-AutoCAD-tool-palettes.html
